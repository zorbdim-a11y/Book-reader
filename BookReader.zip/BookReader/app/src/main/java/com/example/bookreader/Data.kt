package com.example.bookreader

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity data class Category(@PrimaryKey(autoGenerate = true) val id: Long = 0, val name: String)

@Entity data class Book(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val uri: String,
    val categoryId: Long? = null,
    val lastPage: Int = 0
)

@Dao interface BookDao {
    @Query("SELECT * FROM Category ORDER BY name") fun categories(): Flow<List<Category>>
    @Query("SELECT * FROM Book ORDER BY title") fun books(): Flow<List<Book>>
    @Insert suspend fun insertBook(b: Book)
    @Insert suspend fun insertCategory(c: Category)
    @Query("UPDATE Book SET lastPage=:p WHERE id=:id") suspend fun setPage(id: Long, p: Int)
    @Query("UPDATE Book SET categoryId=:c WHERE id=:id") suspend fun setCategory(id: Long, c: Long?)
    @Query("DELETE FROM Book WHERE id=:id") suspend fun deleteBook(id: Long)
}

@Database(entities = [Book::class, Category::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): BookDao
    companion object {
        @Volatile private var inst: AppDb? = null
        fun get(c: Context): AppDb = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(c.applicationContext, AppDb::class.java, "books.db").build().also { inst = it }
        }
    }
}
