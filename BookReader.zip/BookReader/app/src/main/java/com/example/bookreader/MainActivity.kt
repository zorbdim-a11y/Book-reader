package com.example.bookreader

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.debounce

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Surface(Modifier.fillMaxSize()) { App() } } }
    }
}

@Composable
fun App(vm: MainViewModel = viewModel()) {
    val inReader by vm.inReader.collectAsState()
    if (inReader) {
        BackHandler { vm.inReader.value = false }
        ReaderScreen(vm)
    } else LibraryScreen(vm)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LibraryScreen(vm: MainViewModel) {
    val cats by vm.categories.collectAsState()
    val books by vm.books.collectAsState()
    val sel by vm.selectedCategory.collectAsState()
    val tabs by vm.openTabs.collectAsState()
    var showAdd by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { vm.importBooks(it) }

    Scaffold(floatingActionButton = {
        FloatingActionButton(onClick = { picker.launch(arrayOf("application/pdf")) }) { Text("+") }
    }) { pad ->
        Column(Modifier.padding(pad).padding(12.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Βιβλιοθήκη", style = MaterialTheme.typography.headlineSmall)
                if (tabs.isNotEmpty()) TextButton({ vm.inReader.value = true }) { Text("Ανοιχτά (${tabs.size})") }
            }
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 8.dp)) {
                item { FilterChip(sel == null, { vm.selectedCategory.value = null }, { Text("Όλα") }) }
                items(cats) { c -> FilterChip(sel == c.id, { vm.selectedCategory.value = c.id }, { Text(c.name) }) }
                item { AssistChip({ showAdd = true }, { Text("+ Κατηγορία") }) }
            }
            LazyColumn {
                items(books.filter { sel == null || it.categoryId == sel }, key = { it.id }) { b ->
                    var menu by remember { mutableStateOf(false) }
                    Row(Modifier.fillMaxWidth().clickable { vm.openBook(b.id) }.padding(vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            Text(b.title, maxLines = 2)
                            Text(cats.firstOrNull { it.id == b.categoryId }?.name ?: "Χωρίς κατηγορία",
                                style = MaterialTheme.typography.bodySmall)
                        }
                        Box {
                            TextButton({ menu = true }) { Text("⋮") }
                            DropdownMenu(menu, { menu = false }) {
                                cats.forEach { c -> DropdownMenuItem({ Text("→ ${c.name}") }, { vm.setCategory(b.id, c.id); menu = false }) }
                                DropdownMenuItem({ Text("Χωρίς κατηγορία") }, { vm.setCategory(b.id, null); menu = false })
                                DropdownMenuItem({ Text("Διαγραφή από τη λίστα") }, { vm.deleteBook(b.id); menu = false })
                            }
                        }
                    }
                    HorizontalDivider()
                }
            }
        }
    }
    if (showAdd) {
        var name by remember { mutableStateOf("") }
        AlertDialog(onDismissRequest = { showAdd = false },
            title = { Text("Νέα κατηγορία") },
            text = { OutlinedTextField(name, { name = it }, singleLine = true) },
            confirmButton = { TextButton({ vm.addCategory(name); showAdd = false }) { Text("Προσθήκη") } },
            dismissButton = { TextButton({ showAdd = false }) { Text("Άκυρο") } })
    }
}

@Composable
fun ReaderScreen(vm: MainViewModel) {
    val tabs by vm.openTabs.collectAsState()
    val active by vm.activeTab.collectAsState()
    val books by vm.books.collectAsState()
    var zoom by remember { mutableFloatStateOf(1f) }
    // Οθόνη πάντα αναμμένη όσο διαβάζεις (χρήσιμο στη διδασκαλία)
    val view = LocalView.current
    DisposableEffect(Unit) { view.keepScreenOn = true; onDispose { view.keepScreenOn = false } }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            TextButton({ vm.inReader.value = false }) { Text("← Βιβλιοθήκη") }
            Row {
                TextButton({ zoom = (zoom - 0.25f).coerceAtLeast(1f) }) { Text("−") }
                TextButton({ zoom = (zoom + 0.25f).coerceAtMost(3f) }) { Text("+") }
            }
        }
        val idx = tabs.indexOf(active).coerceAtLeast(0)
        if (tabs.isNotEmpty()) ScrollableTabRow(selectedTabIndex = idx, edgePadding = 0.dp) {
            tabs.forEach { id ->
                val title = books.firstOrNull { it.id == id }?.title ?: "…"
                Tab(selected = id == active, onClick = { vm.activeTab.value = id }) {
                    Row(Modifier.padding(horizontal = 12.dp, vertical = 10.dp)) {
                        Text(title, maxLines = 1, modifier = Modifier.widthIn(max = 160.dp))
                        Text("  ✕", Modifier.clickable { vm.closeTab(id) })
                    }
                }
            }
        }
        books.firstOrNull { it.id == active }?.let { b ->
            key(b.id) { PdfView(b, zoom) { page -> vm.savePage(b.id, page) } }
        }
    }
}

@OptIn(FlowPreview::class)
@Composable
fun PdfView(book: Book, zoom: Float, onPage: (Int) -> Unit) {
    val ctx = LocalContext.current
    val doc = remember { runCatching { PdfDoc(ctx, Uri.parse(book.uri)) }.getOrNull() }
    DisposableEffect(Unit) { onDispose { doc?.close() } }
    if (doc == null) { Text("Αδυναμία ανοίγματος του αρχείου", Modifier.padding(16.dp)); return }
    val state = rememberLazyListState(initialFirstVisibleItemIndex = book.lastPage.coerceIn(0, (doc.pageCount - 1).coerceAtLeast(0)))
    LaunchedEffect(state) { snapshotFlow { state.firstVisibleItemIndex }.debounce(500).collect { onPage(it) } }
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val w = maxWidth * zoom
        val widthPx = with(LocalDensity.current) { w.roundToPx() }
        Box(Modifier.horizontalScroll(rememberScrollState())) {
            LazyColumn(state = state, modifier = Modifier.width(w)) {
                items(doc.pageCount) { i -> PageImage(doc, i, widthPx) }
            }
        }
    }
}

@Composable
fun PageImage(doc: PdfDoc, index: Int, widthPx: Int) {
    val bmp by produceState<android.graphics.Bitmap?>(null, doc, index, widthPx) { value = doc.render(index, widthPx) }
    val b = bmp
    if (b != null) Image(b.asImageBitmap(), null, Modifier.fillMaxWidth().padding(bottom = 4.dp), contentScale = ContentScale.FillWidth)
    else Box(Modifier.fillMaxWidth().height(400.dp))
}
