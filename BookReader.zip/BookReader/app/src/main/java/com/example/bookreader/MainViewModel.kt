package com.example.bookreader

import android.app.Application
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDb.get(app).dao()
    val categories = dao.categories().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val books = dao.books().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val selectedCategory = MutableStateFlow<Long?>(null)
    val openTabs = MutableStateFlow<List<Long>>(emptyList())
    val activeTab = MutableStateFlow<Long?>(null)
    val inReader = MutableStateFlow(false)

    fun importBooks(uris: List<Uri>) = viewModelScope.launch {
        val cr = getApplication<Application>().contentResolver
        for (u in uris) {
            runCatching { cr.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            val name = cr.query(u, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(c.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null
            } ?: "Βιβλίο"
            dao.insertBook(Book(title = name.removeSuffix(".pdf"), uri = u.toString(), categoryId = selectedCategory.value))
        }
    }
    fun addCategory(name: String) = viewModelScope.launch { if (name.isNotBlank()) dao.insertCategory(Category(name = name.trim())) }
    fun setCategory(bookId: Long, catId: Long?) = viewModelScope.launch { dao.setCategory(bookId, catId) }
    fun deleteBook(id: Long) { closeTab(id); viewModelScope.launch { dao.deleteBook(id) } }
    fun savePage(id: Long, page: Int) = viewModelScope.launch { dao.setPage(id, page) }

    fun openBook(id: Long) {
        if (id !in openTabs.value) openTabs.value = openTabs.value + id
        activeTab.value = id
        inReader.value = true
    }
    fun closeTab(id: Long) {
        val list = openTabs.value
        val idx = list.indexOf(id)
        val new = list - id
        openTabs.value = new
        if (activeTab.value == id) activeTab.value = new.getOrNull(idx.coerceAtMost(new.size - 1))
        if (new.isEmpty()) inReader.value = false
    }
}
